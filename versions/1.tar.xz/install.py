run("cp /tmp/crab/crab.py /py/crab.py")
